# RegexVault

A fast, minimal, frontend-only developer reference for **regex patterns** and **CSS values** — with multi-language code examples, a live client-side regex tester, search, favorites and dark mode. No backend, no database, no build step.

## Project structure

```text
regexvault/
├── index.html              Home
├── regex.html               Regex Reference (filterable list)
├── regex-detail.html        Regex pattern detail (?id=...)
├── regex-tester.html        Client-side regex tester
├── css-values.html          CSS Values reference (filterable list)
├── css-value-detail.html    CSS value detail (?id=...)
├── favorites.html           Saved patterns/values (localStorage)
├── about.html
├── contact.html
├── 404.html
│
├── css/
│   ├── style.css            Design tokens, resets, base typography
│   ├── components.css       Buttons, nav, cards, code blocks, forms…
│   └── responsive.css       Breakpoint overrides
│
├── js/
│   ├── app.js                Shared helpers: nav, mobile menu, breadcrumbs
│   ├── theme.js               Light/dark theme toggle
│   ├── clipboard.js           Copy-to-clipboard + toast
│   ├── favorites.js           localStorage favorites
│   ├── search.js              Global instant search (nav + hero)
│   ├── regex.js                Regex rendering, multi-language code generation, breakdown tokenizer
│   ├── css-values.js           CSS value rendering
│   └── regex-tester.js         Regex tester logic
│
├── data/
│   ├── regex-patterns.js     52 regex patterns (source of truth)
│   └── css-values.js         37 CSS units/values
│
├── assets/icons/icon.svg     Favicon / PWA icon
├── robots.txt
├── sitemap.xml
├── manifest.webmanifest
└── README.md
```

## How the multi-language code samples work

Rather than hand-writing ten language snippets per pattern (500+ snippets prone to copy/paste drift), each regex entry stores **one** pattern + flag set. `js/regex.js` derives all ten language samples at render time — handling each language's string-escaping rules (raw strings vs. regular string literals, delimiter choice, flag translation) in one place. See the comments at the top of `js/regex.js` for the details.

## Running locally

No build step or dependencies are required. Any static file server works, for example:

```bash
cd regexvault
python3 -m http.server 8000
# then open http://localhost:8000
```

or, with Node installed:

```bash
npx serve .
```

Opening `index.html` directly via `file://` mostly works too, but a local server is recommended so relative fetches behave exactly like production.

## Deploying

RegexVault is static output — deploy it to any static host:

- **Netlify** — drag-and-drop the folder, or connect the repo (no build command needed; publish directory = `/`).
- **Vercel** — import the repo as a static project (no framework preset).
- **GitHub Pages** — push to a repo and enable Pages on the root or `/docs` folder.
- **Cloudflare Pages** — connect the repo with no build command; output directory = `/`.

Before going live:

1. Replace `https://regexvault.example.com` in `index.html` (and every other page's `<link rel="canonical">` / Open Graph tags), `robots.txt` and `sitemap.xml` with your real production domain.
2. Wire `contact.html`'s form to a real backend or a form service (e.g. Formspree, Netlify Forms) if you want submissions to actually arrive somewhere — right now it's intentionally a validated, client-side-only demo.
3. Regenerate `sitemap.xml` if you add or remove entries in `data/regex-patterns.js` / `data/css-values.js` (it currently lists every pattern and value by id).

## Notes on data quality

Every regex pattern in `data/regex-patterns.js` is a real, working pattern with valid/invalid examples that actually match/don't match. Patterns that are deliberately simplified (e.g. basic email validation) say so in a `note` field, which renders as a callout on the detail page — RegexVault doesn't claim a simple pattern perfectly validates something as complex as RFC 5322 email addresses.

## License / attribution

No third-party runtime dependencies are bundled. Fonts (Space Grotesk, Source Sans 3, JetBrains Mono) are loaded from Google Fonts — replace with self-hosted files if you need to avoid that external request.

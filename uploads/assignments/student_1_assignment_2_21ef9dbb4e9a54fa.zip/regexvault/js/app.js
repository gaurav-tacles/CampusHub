/**
 * app.js — shared utilities and global chrome (nav, mobile menu, breadcrumbs).
 * Loaded on every page, before the page-specific module.
 */
window.RegexVaultApp = (function () {
  "use strict";

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function qs(name, fallback) {
    const params = new URLSearchParams(window.location.search);
    return params.has(name) ? params.get(name) : fallback;
  }

  function debounce(fn, wait) {
    let t;
    return function debounced(...args) {
      clearTimeout(t);
      t = setTimeout(() => fn.apply(this, args), wait);
    };
  }

  function el(tag, attrs, children) {
    const node = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach((key) => {
        if (key === "class") node.className = attrs[key];
        else if (key === "html") node.innerHTML = attrs[key];
        else node.setAttribute(key, attrs[key]);
      });
    }
    (children || []).forEach((child) => {
      if (child) node.appendChild(child);
    });
    return node;
  }

  function renderBreadcrumbs(mountSelector, crumbs) {
    const mount = document.querySelector(mountSelector);
    if (!mount) return;
    mount.setAttribute("aria-label", "Breadcrumb");
    const parts = [];
    crumbs.forEach((crumb, index) => {
      if (index > 0) {
        const sep = document.createElement("span");
        sep.className = "sep";
        sep.textContent = "/";
        sep.setAttribute("aria-hidden", "true");
        parts.push(sep);
      }
      if (crumb.href && index < crumbs.length - 1) {
        const a = document.createElement("a");
        a.href = crumb.href;
        a.textContent = crumb.label;
        parts.push(a);
      } else {
        const span = document.createElement("span");
        span.textContent = crumb.label;
        span.setAttribute("aria-current", "page");
        parts.push(span);
      }
    });
    mount.innerHTML = "";
    parts.forEach((p) => mount.appendChild(p));

    // BreadcrumbList structured data, built from the same source of truth.
    const script = document.createElement("script");
    script.type = "application/ld+json";
    script.textContent = JSON.stringify({
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      itemListElement: crumbs.map((crumb, i) => ({
        "@type": "ListItem",
        position: i + 1,
        name: crumb.label,
        item: crumb.href ? new URL(crumb.href, window.location.origin).href : window.location.href
      }))
    });
    document.head.appendChild(script);
  }

  function setActiveNav() {
    const path = window.location.pathname.split("/").pop() || "index.html";
    document.querySelectorAll(".main-nav a, .mobile-menu a").forEach((link) => {
      const href = link.getAttribute("href");
      if (href === path || (path === "" && href === "index.html")) {
        link.setAttribute("aria-current", "page");
      }
    });
  }

  function initMobileMenu() {
    const toggle = document.querySelector("[data-menu-toggle]");
    const menu = document.querySelector("[data-mobile-menu]");
    const closeBtn = document.querySelector("[data-menu-close]");
    if (!toggle || !menu) return;

    function open() {
      menu.classList.add("is-open");
      toggle.setAttribute("aria-expanded", "true");
      const firstLink = menu.querySelector("a");
      if (firstLink) firstLink.focus();
    }
    function close() {
      menu.classList.remove("is-open");
      toggle.setAttribute("aria-expanded", "false");
      toggle.focus();
    }
    toggle.addEventListener("click", () => {
      menu.classList.contains("is-open") ? close() : open();
    });
    if (closeBtn) closeBtn.addEventListener("click", close);
    menu.querySelectorAll("a").forEach((a) => a.addEventListener("click", close));
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && menu.classList.contains("is-open")) close();
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    setActiveNav();
    initMobileMenu();
  });

  return { escapeHtml, qs, debounce, el, renderBreadcrumbs };
})();

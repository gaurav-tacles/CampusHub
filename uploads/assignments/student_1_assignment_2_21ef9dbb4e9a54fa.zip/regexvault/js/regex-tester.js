/**
 * regex-tester.js — powers regex-tester.html.
 * Everything here runs entirely client-side: the pattern and test text
 * never leave the browser. No eval() is used anywhere in this file.
 */
(function () {
  "use strict";

  const MAX_MATCHES = 500; // guards against runaway loops on pathological patterns
  const MAX_TEST_TEXT_LENGTH = 20000; // keeps highlighting/rendering responsive

  const els = {};

  function cacheEls() {
    els.patternInput = document.getElementById("regex-pattern-input");
    els.flagsInput = document.getElementById("regex-flags-input");
    els.flagChecks = document.querySelectorAll("[data-flag-check]");
    els.testTextInput = document.getElementById("test-text-input");
    els.status = document.getElementById("tester-status");
    els.highlighted = document.getElementById("highlighted-output");
    els.matchList = document.getElementById("match-list");
    els.matchCount = document.getElementById("match-count");
    els.form = document.getElementById("regex-tester-form");
  }

  function currentFlagsFromChecks() {
    return Array.from(els.flagChecks)
      .filter((cb) => cb.checked)
      .map((cb) => cb.value)
      .join("");
  }

  function syncFlagsInputFromChecks() {
    els.flagsInput.value = currentFlagsFromChecks();
  }

  function syncChecksFromFlagsInput() {
    const value = els.flagsInput.value;
    els.flagChecks.forEach((cb) => {
      cb.checked = value.includes(cb.value);
    });
  }

  function setStatus(mode, text) {
    els.status.className = "tester-status status-" + mode;
    els.status.textContent = text;
  }

  function escapeHtml(str) {
    return window.RegexVaultApp.escapeHtml(str);
  }

  function renderHighlighted(text, ranges) {
    if (!ranges.length) {
      els.highlighted.innerHTML = escapeHtml(text) || '<span style="color:var(--ink-faint)">Nothing to display yet.</span>';
      return;
    }
    let out = "";
    let cursor = 0;
    ranges.forEach(([start, end]) => {
      out += escapeHtml(text.slice(cursor, start));
      out += "<mark>" + escapeHtml(text.slice(start, end)) + "</mark>";
      cursor = end;
    });
    out += escapeHtml(text.slice(cursor));
    els.highlighted.innerHTML = out;
  }

  function renderMatchList(matches) {
    if (!matches.length) {
      els.matchList.innerHTML = "";
      return;
    }
    els.matchList.innerHTML = matches
      .map((m, i) => {
        const groups = m.groups && m.groups.length
          ? " — groups: " + m.groups.map((g, gi) => `[${gi + 1}] ${g === undefined ? "(no match)" : `"${escapeHtml(g)}"`}`).join(", ")
          : "";
        return `<div class="match-item"><span class="match-index">#${i + 1} @ ${m.index}</span>"${escapeHtml(m.text)}"${groups}</div>`;
      })
      .join("");
  }

  function runTest() {
    const patternSrc = els.patternInput.value;
    let flags = currentFlagsFromChecks();
    els.flagsInput.value = flags;
    const testText = els.testTextInput.value.slice(0, MAX_TEST_TEXT_LENGTH);

    if (!patternSrc) {
      setStatus("nomatch", "Enter a pattern to test");
      renderHighlighted(testText, []);
      renderMatchList([]);
      els.matchCount.textContent = "0";
      return;
    }

    let regex;
    try {
      regex = new RegExp(patternSrc, flags);
    } catch (err) {
      setStatus("error", "Invalid pattern — " + err.message);
      renderHighlighted(testText, []);
      renderMatchList([]);
      els.matchCount.textContent = "0";
      return;
    }

    const matches = [];
    const ranges = [];

    try {
      if (flags.includes("g")) {
        let m;
        let guard = 0;
        while ((m = regex.exec(testText)) !== null && guard < MAX_MATCHES) {
          matches.push({ text: m[0], index: m.index, groups: m.slice(1) });
          ranges.push([m.index, m.index + m[0].length]);
          if (m[0].length === 0) regex.lastIndex++; // avoid infinite loop on zero-length matches
          guard++;
        }
      } else {
        const m = regex.exec(testText);
        if (m) {
          matches.push({ text: m[0], index: m.index, groups: m.slice(1) });
          ranges.push([m.index, m.index + m[0].length]);
        }
      }
    } catch (err) {
      setStatus("error", "Error while matching — " + err.message);
      return;
    }

    if (matches.length) {
      setStatus("match", `Match — ${matches.length} ${matches.length === 1 ? "match" : "matches"} found`);
    } else {
      setStatus("nomatch", "No match");
    }
    els.matchCount.textContent = String(matches.length);
    renderHighlighted(testText, ranges);
    renderMatchList(matches);
  }

  const EXAMPLES = {
    email: { pattern: "^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$", flags: "g", text: "user@example.com\nnot-an-email\nsecond.user@mail.co" },
    phone: { pattern: "\\(?\\d{3}\\)?[\\s.-]?\\d{3}[\\s.-]?\\d{4}", flags: "g", text: "Call (555) 123-4567 or 555.987.6543. Not a phone: 12345." },
    name: { pattern: "[A-Za-z]+(?:[\\s'-][A-Za-z]+)+", flags: "g", text: "Gaurav Patel and Mary-Jane O'Brien attended, but Cher did not." },
    url: { pattern: "https?:\\/\\/[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]+)+([\\/\\w .-]*)*\\/?", flags: "g", text: "Visit https://example.com/docs or http://sub.example.co/a/b for details." }
  };

  function loadExample(key) {
    const ex = EXAMPLES[key];
    if (!ex) return;
    els.patternInput.value = ex.pattern;
    els.flagsInput.value = ex.flags;
    syncChecksFromFlagsInput();
    els.testTextInput.value = ex.text;
    runTest();
    els.patternInput.focus();
  }

  function init() {
    cacheEls();
    if (!els.form) return;

    const idFromQuery = window.RegexVaultApp.qs("id");
    const langFromQuery = window.RegexVaultApp.qs("lang");
    if (idFromQuery && window.RegexVaultRegex) {
      const entry = window.RegexVaultRegex.getById(idFromQuery);
      if (entry) {
        els.patternInput.value = entry.pattern;
        els.flagsInput.value = entry.flags || "";
        els.testTextInput.value = (entry.examples.valid[0] || "") + "\n" + (entry.examples.invalid[0] || "");
      }
    }
    void langFromQuery; // reserved for potential future language-aware examples

    syncChecksFromFlagsInput();

    els.patternInput.addEventListener("input", runTest);
    els.testTextInput.addEventListener("input", runTest);
    els.flagChecks.forEach((cb) => cb.addEventListener("change", runTest));
    els.flagsInput.addEventListener("input", () => {
      syncChecksFromFlagsInput();
      runTest();
    });

    document.querySelectorAll("[data-example]").forEach((btn) => {
      btn.addEventListener("click", () => loadExample(btn.getAttribute("data-example")));
    });

    els.form.addEventListener("submit", (e) => {
      e.preventDefault();
      runTest();
    });

    runTest();
  }

  document.addEventListener("DOMContentLoaded", init);
})();

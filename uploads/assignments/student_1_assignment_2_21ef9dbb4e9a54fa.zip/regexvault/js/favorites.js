/**
 * favorites.js — bookmark regex patterns and CSS values via localStorage.
 * Storage shape: { "regex:email-basic": true, "css:rem": true }
 */
(function () {
  "use strict";

  const STORAGE_KEY = "regexvault:favorites";

  function readAll() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch (err) {
      return {};
    }
  }

  function writeAll(data) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
      return true;
    } catch (err) {
      return false;
    }
  }

  function key(type, id) {
    return type + ":" + id;
  }

  function isFavorite(type, id) {
    const data = readAll();
    return Boolean(data[key(type, id)]);
  }

  function toggle(type, id) {
    const data = readAll();
    const k = key(type, id);
    if (data[k]) {
      delete data[k];
    } else {
      data[k] = true;
    }
    writeAll(data);
    updateHeaderCount();
    return Boolean(data[k]);
  }

  function list() {
    const data = readAll();
    return Object.keys(data).map((k) => {
      const [type, ...rest] = k.split(":");
      return { type, id: rest.join(":") };
    });
  }

  function count() {
    return Object.keys(readAll()).length;
  }

  function updateHeaderCount() {
    const badge = document.querySelector("[data-fav-count]");
    if (!badge) return;
    const n = count();
    badge.textContent = String(n);
    badge.hidden = n === 0;
  }

  function initToggleButtons(root) {
    (root || document).querySelectorAll("[data-fav-toggle]").forEach((btn) => {
      const type = btn.getAttribute("data-fav-type");
      const id = btn.getAttribute("data-fav-id");
      if (!type || !id) return;
      const active = isFavorite(type, id);
      btn.setAttribute("aria-pressed", String(active));
      btn.textContent = active ? "★" : "☆";
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        const nowActive = toggle(type, id);
        btn.setAttribute("aria-pressed", String(nowActive));
        btn.textContent = nowActive ? "★" : "☆";
        btn.setAttribute(
          "aria-label",
          (nowActive ? "Remove from favorites: " : "Add to favorites: ") +
            (btn.getAttribute("data-fav-title") || "")
        );
      });
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    initToggleButtons(document);
    updateHeaderCount();
  });

  window.RegexVaultFavorites = {
    isFavorite,
    toggle,
    list,
    count,
    initToggleButtons,
    updateHeaderCount
  };
})();

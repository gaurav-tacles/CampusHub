/**
 * regex.js — everything specific to the Regex Reference:
 *  - deriving 10-language code samples from a single `pattern` + `flags`
 *  - a lightweight regex tokenizer that powers the beginner-friendly breakdown
 *  - rendering the card grid (regex.html) and the detail page (regex-detail.html)
 *
 * Generating code from one source of truth (instead of hand-writing 10
 * snippets per pattern) keeps every language sample in sync with the
 * pattern and avoids the copy/paste drift that causes subtly wrong regex
 * escaping between languages.
 */
window.RegexVaultRegex = (function () {
  "use strict";

  const { escapeHtml } = window.RegexVaultApp;
  const DATA = window.REGEX_PATTERNS || [];

  const LANGUAGES = [
    { id: "dart", label: "Dart" },
    { id: "python", label: "Python" },
    { id: "javascript", label: "JavaScript" },
    { id: "java", label: "Java" },
    { id: "php", label: "PHP" },
    { id: "csharp", label: "C#" },
    { id: "cpp", label: "C++" },
    { id: "ruby", label: "Ruby" },
    { id: "go", label: "Go" },
    { id: "kotlin", label: "Kotlin" }
  ];

  const CURATED_POPULAR_IDS = [
    "email-basic",
    "password-strong",
    "phone-us",
    "url-http",
    "hex-color",
    "uuid-v4",
    "date-iso",
    "ipv4",
    "username",
    "otp-6"
  ];

  // ---------- Lookup helpers ----------

  function getAll() {
    return DATA;
  }

  function getById(id) {
    return DATA.find((entry) => entry.id === id) || null;
  }

  function getCategories() {
    const set = new Set(DATA.map((entry) => entry.category));
    return Array.from(set).sort();
  }

  function pascalWords(id) {
    return id.split("-").map((w) => w.charAt(0).toUpperCase() + w.slice(1));
  }

  function functionNamePascal(id) {
    return "is" + pascalWords(id).join("");
  }

  function functionNameSnake(id) {
    return "is_" + id.replace(/-/g, "_");
  }

  // ---------- Per-language escaping + flags ----------

  function escapeForLang(pattern, lang) {
    switch (lang) {
      case "javascript":
      case "ruby":
        return pattern.replace(/\//g, "\\/");
      case "java":
        return pattern.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
      case "csharp":
        return pattern.replace(/"/g, '""');
      case "kotlin":
        // Function replacer avoids `$'`/`$&`-style special replacement patterns
        // that `String.replace` would otherwise interpret in a plain string arg.
        return pattern.replace(/\$/g, () => "${'$'}");
      default:
        // python, dart, php, cpp, go all use raw/verbatim string forms
        // where a JS-regex-style backslash sequence needs no re-escaping.
        return pattern;
    }
  }

  function flagsForLang(lang, flags) {
    const i = flags.indexOf("i") !== -1;
    switch (lang) {
      case "javascript":
        return flags;
      case "ruby":
        return i ? "i" : "";
      case "python":
        return i ? ", re.IGNORECASE" : "";
      case "dart":
        return i ? ", caseSensitive: false" : "";
      case "java":
        return i ? ", Pattern.CASE_INSENSITIVE" : "";
      case "php":
        return i ? "i" : "";
      case "csharp":
        return i ? ", RegexOptions.IgnoreCase" : "";
      case "cpp":
        return i ? ", std::regex::icase" : "";
      case "go":
        return i ? "(?i)" : "";
      case "kotlin":
        return i ? ", RegexOption.IGNORE_CASE" : "";
      default:
        return "";
    }
  }

  // PHP's PCRE pattern string needs a delimiter character that doesn't
  // appear literally in the pattern itself (most patterns use "/", but a
  // few — like the strict email pattern's allowed-character class — contain
  // "/" as content, so a fixed delimiter isn't safe for every entry).
  const PHP_DELIMITER_CANDIDATES = ["/", "~", "#", "%", "!", ";", ",", ":", "|", "@"];

  function pickPhpDelimiter(pattern) {
    return PHP_DELIMITER_CANDIDATES.find((d) => !pattern.includes(d)) || "~";
  }

  // Go's backtick raw string breaks if the pattern itself contains a
  // backtick; fall back to a normal interpreted string literal in that case.
  function goPatternLiteral(fullPattern) {
    if (!fullPattern.includes("`")) {
      return "`" + fullPattern + "`";
    }
    const escaped = fullPattern.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
    return '"' + escaped + '"';
  }

  // Dart's raw string normally uses single quotes; fall back to a raw
  // double-quoted string when the pattern itself contains a literal '.
  function dartPatternLiteral(pattern) {
    return pattern.includes("'") ? `r"${pattern}"` : `r'${pattern}'`;
  }

  function buildSnippet(lang, entry) {
    const p = entry.pattern;
    const flags = entry.flags || "";
    const escaped = escapeForLang(p, lang);
    const langFlags = flagsForLang(lang, flags);
    const fnPascal = functionNamePascal(entry.id);
    const fnSnake = functionNameSnake(entry.id);

    switch (lang) {
      case "dart":
        return (
          `final pattern = RegExp(${dartPatternLiteral(escaped)}${langFlags});\n\n` +
          `bool ${fnPascal}(String value) {\n  return pattern.hasMatch(value);\n}`
        );
      case "python":
        return (
          `import re\n\n` +
          `pattern = re.compile(r"${escaped}"${langFlags})\n\n` +
          `def ${fnSnake}(value):\n    return bool(pattern.search(value))`
        );
      case "javascript":
        return (
          `const pattern = /${escaped}/${langFlags};\n\n` +
          `function ${fnPascal}(value) {\n  return pattern.test(value);\n}`
        );
      case "java":
        return (
          `import java.util.regex.Pattern;\n\n` +
          `Pattern pattern = Pattern.compile("${escaped}"${langFlags});\n\n` +
          `boolean ${fnPascal}(String value) {\n    return pattern.matcher(value).find();\n}`
        );
      case "php": {
        const delim = pickPhpDelimiter(p);
        // Escape any literal occurrence of the chosen delimiter within the
        // pattern itself — needed whenever the delimiter is "/" (the most
        // common case) since a plain regex source doesn't pre-escape it.
        const phpSafe = p.split(delim).join("\\" + delim);
        return (
          `$pattern = '${delim}${phpSafe}${delim}${langFlags}';\n\n` +
          `function ${fnPascal}($value) {\n    return preg_match($pattern, $value) === 1;\n}`
        );
      }
      case "csharp":
        return (
          `using System.Text.RegularExpressions;\n\n` +
          `var pattern = new Regex(@"${escaped}"${langFlags});\n\n` +
          `bool ${fnPascal}(string value)\n{\n    return pattern.IsMatch(value);\n}`
        );
      case "cpp":
        return (
          `#include <regex>\n\n` +
          `std::regex pattern(R"(${escaped})"${langFlags});\n\n` +
          `bool ${fnSnake}(const std::string& value) {\n    return std::regex_search(value, pattern);\n}`
        );
      case "ruby":
        return (
          `pattern = /${escaped}/${langFlags}\n\n` +
          `def ${fnSnake}(value)\n  !!(value =~ pattern)\nend`
        );
      case "go":
        return (
          `package main\n\n` +
          `import "regexp"\n\n` +
          `var pattern = regexp.MustCompile(${goPatternLiteral(langFlags + escaped)})\n\n` +
          `func ${fnPascal}(value string) bool {\n\treturn pattern.MatchString(value)\n}`
        );
      case "kotlin":
        return (
          `val pattern = Regex("""${escaped}"""${langFlags})\n\n` +
          `fun ${fnPascal}(value: String): Boolean {\n    return pattern.containsMatchIn(value)\n}`
        );
      default:
        return "";
    }
  }

  function buildLanguageExamples(entry) {
    const out = {};
    LANGUAGES.forEach((lang) => {
      out[lang.id] = buildSnippet(lang.id, entry);
    });
    return out;
  }

  // ---------- Beginner-friendly token breakdown ----------

  const ESCAPE_DESCRIPTIONS = {
    d: "Any digit (0–9)",
    D: "Any character that is NOT a digit",
    w: "Any word character — a letter, digit or underscore",
    W: "Any character that is NOT a word character",
    s: "Any whitespace character (space, tab, newline)",
    S: "Any character that is NOT whitespace",
    b: "A word boundary (the edge between a word character and a non-word character)",
    B: "A position that is NOT a word boundary",
    n: "A newline character",
    t: "A tab character",
    ".": "A literal period",
    "/": "A literal forward slash",
    "\\": "A literal backslash",
    "+": "A literal plus sign",
    "-": "A literal hyphen"
  };

  function describeGroup(group) {
    if (group.startsWith("(?:")) return "Non-capturing group";
    if (group.startsWith("(?=")) return "Positive lookahead — must be followed by this, without consuming it";
    if (group.startsWith("(?!")) return "Negative lookahead — must NOT be followed by this";
    if (group.startsWith("(?<=")) return "Positive lookbehind — must be preceded by this, without consuming it";
    if (group.startsWith("(?<!")) return "Negative lookbehind — must NOT be preceded by this";
    if (/^\(\?<[A-Za-z]/.test(group)) return "Named capturing group";
    return "Capturing group — remembers what it matches";
  }

  function breakdownPattern(pattern) {
    const tokens = [];
    let i = 0;
    const n = pattern.length;
    let literalBuffer = "";

    function flushLiteral() {
      if (literalBuffer) {
        tokens.push({
          token: literalBuffer,
          desc: `Literal text — matches exactly "${literalBuffer}"`
        });
        literalBuffer = "";
      }
    }

    while (i < n) {
      const c = pattern[i];

      if (c === "^") {
        flushLiteral();
        tokens.push({ token: "^", desc: "Anchors the match to the start of the string" });
        i++;
        continue;
      }
      if (c === "$") {
        flushLiteral();
        tokens.push({ token: "$", desc: "Anchors the match to the end of the string" });
        i++;
        continue;
      }
      if (c === ".") {
        flushLiteral();
        tokens.push({ token: ".", desc: "Matches any single character except a line break" });
        i++;
        continue;
      }
      if (c === "|") {
        flushLiteral();
        tokens.push({ token: "|", desc: "Alternation — matches whatever appears on either side" });
        i++;
        continue;
      }
      if (c === "\\") {
        flushLiteral();
        const next = pattern[i + 1];
        let desc;
        if (/[1-9]/.test(next)) {
          desc = `Backreference to capturing group ${next} — matches whatever that group matched`;
        } else {
          desc = ESCAPE_DESCRIPTIONS[next] || `Escaped literal character "${next}"`;
        }
        tokens.push({ token: "\\" + next, desc });
        i += 2;
        continue;
      }
      if (c === "[") {
        flushLiteral();
        let j = i + 1;
        let neg = false;
        if (pattern[j] === "^") {
          neg = true;
          j++;
        }
        while (j < n && pattern[j] !== "]") {
          if (pattern[j] === "\\") j++;
          j++;
        }
        const cls = pattern.slice(i, j + 1);
        const inner = cls.replace(/^\[\^?/, "").replace(/\]$/, "");
        tokens.push({
          token: cls,
          desc: (neg ? "Any character NOT in this set: " : "Any one character from this set: ") + inner
        });
        i = j + 1;
        continue;
      }
      if (c === "(") {
        flushLiteral();
        let depth = 1;
        let j = i + 1;
        while (j < n && depth > 0) {
          if (pattern[j] === "\\") {
            j += 2;
            continue;
          }
          if (pattern[j] === "(") depth++;
          else if (pattern[j] === ")") depth--;
          j++;
        }
        const group = pattern.slice(i, j);
        tokens.push({ token: group, desc: describeGroup(group) });
        i = j;
        continue;
      }
      if (c === "*" || c === "+" || c === "?") {
        flushLiteral();
        const desc =
          c === "*"
            ? "Zero or more of the preceding token"
            : c === "+"
            ? "One or more of the preceding token"
            : "Zero or one of the preceding token (makes it optional)";
        tokens.push({ token: c, desc });
        i++;
        continue;
      }
      if (c === "{") {
        flushLiteral();
        let j = i;
        while (j < n && pattern[j] !== "}") j++;
        const quant = pattern.slice(i, j + 1);
        tokens.push({ token: quant, desc: `Repeats the preceding token according to ${quant}` });
        i = j + 1;
        continue;
      }

      literalBuffer += c;
      i++;
    }
    flushLiteral();
    return tokens;
  }

  // ---------- Search index ----------

  function searchIndex() {
    return DATA.map((entry) => ({
      type: "regex",
      id: entry.id,
      title: entry.title,
      category: entry.category,
      href: `regex-detail.html?id=${encodeURIComponent(entry.id)}`,
      haystack: [
        entry.title,
        entry.pattern,
        entry.category,
        entry.description,
        (entry.keywords || []).join(" "),
        "dart python javascript java php csharp c# cpp c++ ruby go kotlin"
      ]
        .join(" ")
        .toLowerCase()
    }));
  }

  // ---------- Rendering: card grid ----------

  function cardTemplate(entry) {
    const fav = window.RegexVaultFavorites;
    const isFav = fav ? fav.isFavorite("regex", entry.id) : false;
    return `
      <a class="pattern-card" href="regex-detail.html?id=${encodeURIComponent(entry.id)}" data-id="${entry.id}">
        <div class="pattern-card-top">
          <h3>${escapeHtml(entry.title)}</h3>
          <button type="button" class="fav-toggle" data-fav-toggle data-fav-type="regex" data-fav-id="${entry.id}"
            data-fav-title="${escapeHtml(entry.title)}" aria-pressed="${isFav}"
            aria-label="${isFav ? "Remove from favorites: " : "Add to favorites: "}${escapeHtml(entry.title)}">${isFav ? "★" : "☆"}</button>
        </div>
        <span class="category-tag">${escapeHtml(entry.category)}</span>
        <p>${escapeHtml(entry.description)}</p>
        <code class="mono-preview">${escapeHtml(entry.pattern)}</code>
      </a>`;
  }

  function renderList(mountSelector, entries) {
    const mount = document.querySelector(mountSelector);
    if (!mount) return;
    if (!entries.length) {
      mount.innerHTML = "";
      return;
    }
    mount.innerHTML = entries.map(cardTemplate).join("");
    if (window.RegexVaultFavorites) {
      window.RegexVaultFavorites.initToggleButtons(mount);
    }
  }

  function sortEntries(entries, mode) {
    const copy = entries.slice();
    if (mode === "az") {
      copy.sort((a, b) => a.title.localeCompare(b.title));
    } else if (mode === "popular") {
      copy.sort((a, b) => {
        const ai = CURATED_POPULAR_IDS.indexOf(a.id);
        const bi = CURATED_POPULAR_IDS.indexOf(b.id);
        if (ai === -1 && bi === -1) return a.title.localeCompare(b.title);
        if (ai === -1) return 1;
        if (bi === -1) return -1;
        return ai - bi;
      });
    } else if (mode === "recent") {
      copy.reverse();
    }
    return copy;
  }

  // ---------- Rendering: detail page ----------

  function relatedEntries(entry, limit) {
    return DATA.filter((e) => e.category === entry.category && e.id !== entry.id).slice(0, limit || 6);
  }

  return {
    LANGUAGES,
    getAll,
    getById,
    getCategories,
    buildLanguageExamples,
    breakdownPattern,
    searchIndex,
    renderList,
    sortEntries,
    relatedEntries,
    cardTemplate
  };
})();

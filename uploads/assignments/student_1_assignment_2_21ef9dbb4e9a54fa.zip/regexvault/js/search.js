/**
 * search.js — global instant search across Regex patterns and CSS values.
 * Wires up any [data-search-input] + its sibling [data-search-results] pair,
 * so the same markup pattern works in the nav bar and on the homepage hero.
 */
(function () {
  "use strict";

  const SUGGESTIONS = ["email", "phone", "password", "username", "rem", "viewport", "uuid", "hex color"];

  function buildIndex() {
    const regexIndex = window.RegexVaultRegex ? window.RegexVaultRegex.searchIndex() : [];
    const cssIndex = window.RegexVaultCss ? window.RegexVaultCss.searchIndex() : [];
    return regexIndex.concat(cssIndex);
  }

  function runQuery(index, query) {
    const q = query.trim().toLowerCase();
    if (!q) return { regex: [], css: [] };
    const matches = index.filter((item) => item.haystack.includes(q));
    return {
      regex: matches.filter((m) => m.type === "regex").slice(0, 8),
      css: matches.filter((m) => m.type === "css").slice(0, 8)
    };
  }

  function emptyStateHtml() {
    const chips = SUGGESTIONS.map((s) => `<li>${s}</li>`).join("");
    return `
      <div class="search-empty">
        No results found.
        <br />Try one of these:
        <ul>${chips}</ul>
      </div>`;
  }

  function resultsHtml(grouped) {
    const escapeHtml = window.RegexVaultApp.escapeHtml;
    if (!grouped.regex.length && !grouped.css.length) return emptyStateHtml();
    let html = "";
    if (grouped.regex.length) {
      html += `<div class="search-group-label">Regex</div>`;
      grouped.regex.forEach((item) => {
        html += `<a class="search-result" href="${item.href}" role="option">
          <strong>${escapeHtml(item.title)}</strong>
          <span>${escapeHtml(item.category)}</span>
        </a>`;
      });
    }
    if (grouped.css.length) {
      html += `<div class="search-group-label">CSS Values</div>`;
      grouped.css.forEach((item) => {
        html += `<a class="search-result" href="${item.href}" role="option">
          <strong>${escapeHtml(item.title)}</strong>
          <span>${escapeHtml(item.category)}</span>
        </a>`;
      });
    }
    return html;
  }

  function initSearchWidget(input) {
    const resultsMount = document.getElementById(input.getAttribute("data-search-input"));
    if (!resultsMount) return;
    const index = buildIndex();

    function open() {
      resultsMount.classList.add("is-open");
      input.setAttribute("aria-expanded", "true");
    }
    function close() {
      resultsMount.classList.remove("is-open");
      input.setAttribute("aria-expanded", "false");
    }
    function update() {
      const value = input.value;
      if (!value.trim()) {
        resultsMount.innerHTML = "";
        close();
        return;
      }
      const grouped = runQuery(index, value);
      resultsMount.innerHTML = resultsHtml(grouped);
      open();
    }

    input.setAttribute("role", "combobox");
    input.setAttribute("aria-expanded", "false");
    input.setAttribute("aria-controls", resultsMount.id);
    resultsMount.setAttribute("role", "listbox");

    input.addEventListener("input", window.RegexVaultApp.debounce(update, 120));
    input.addEventListener("focus", () => {
      if (input.value.trim()) update();
    });

    document.addEventListener("click", (e) => {
      if (!input.contains(e.target) && !resultsMount.contains(e.target)) close();
    });

    input.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        close();
        input.blur();
        return;
      }
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        const options = Array.from(resultsMount.querySelectorAll(".search-result"));
        if (!options.length) return;
        e.preventDefault();
        const activeIndex = options.findIndex((o) => o.classList.contains("is-active"));
        let nextIndex;
        if (e.key === "ArrowDown") {
          nextIndex = activeIndex < options.length - 1 ? activeIndex + 1 : 0;
        } else {
          nextIndex = activeIndex > 0 ? activeIndex - 1 : options.length - 1;
        }
        options.forEach((o) => o.classList.remove("is-active"));
        options[nextIndex].classList.add("is-active");
        options[nextIndex].scrollIntoView({ block: "nearest" });
      }
      if (e.key === "Enter") {
        const active = resultsMount.querySelector(".search-result.is-active");
        if (active) {
          e.preventDefault();
          window.location.href = active.getAttribute("href");
        }
      }
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll("[data-search-input]").forEach(initSearchWidget);
  });
})();

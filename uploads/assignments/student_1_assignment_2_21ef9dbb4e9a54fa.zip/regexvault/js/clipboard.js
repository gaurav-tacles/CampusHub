/**
 * clipboard.js — copy-to-clipboard with visible, non-blocking feedback.
 * Delegated: any element with [data-copy-text] or [data-copy-target]
 * becomes a working copy button without extra wiring.
 */
(function () {
  "use strict";

  function showToast(message) {
    let toast = document.querySelector(".toast");
    if (!toast) {
      toast = document.createElement("div");
      toast.className = "toast";
      toast.setAttribute("role", "status");
      toast.setAttribute("aria-live", "polite");
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.classList.add("is-visible");
    clearTimeout(toast._hideTimer);
    toast._hideTimer = setTimeout(() => {
      toast.classList.remove("is-visible");
    }, 1800);
  }

  async function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
      try {
        await navigator.clipboard.writeText(text);
        return true;
      } catch (err) {
        /* fall through to legacy method */
      }
    }
    try {
      const helper = document.createElement("textarea");
      helper.value = text;
      helper.setAttribute("readonly", "");
      helper.style.position = "fixed";
      helper.style.left = "-9999px";
      document.body.appendChild(helper);
      helper.select();
      const ok = document.execCommand("copy");
      document.body.removeChild(helper);
      return ok;
    } catch (err) {
      return false;
    }
  }

  function markCopied(button) {
    const original = button.dataset.originalLabel || button.textContent.trim();
    button.dataset.originalLabel = original;
    button.textContent = "✓ Copied";
    button.classList.add("is-copied");
    clearTimeout(button._resetTimer);
    button._resetTimer = setTimeout(() => {
      button.textContent = original;
      button.classList.remove("is-copied");
    }, 1600);
  }

  async function handleClick(event) {
    const button = event.target.closest("[data-copy-text], [data-copy-target]");
    if (!button) return;

    let text = button.getAttribute("data-copy-text");
    if (!text) {
      const targetSelector = button.getAttribute("data-copy-target");
      const targetEl = targetSelector && document.querySelector(targetSelector);
      text = targetEl ? targetEl.textContent : "";
    }
    if (!text) return;

    const ok = await copyText(text);
    if (ok) {
      markCopied(button);
      showToast("Copied to clipboard");
    } else {
      showToast("Couldn't copy — select and copy manually");
    }
  }

  document.addEventListener("click", handleClick);

  window.RegexVaultClipboard = { copyText, showToast };
})();

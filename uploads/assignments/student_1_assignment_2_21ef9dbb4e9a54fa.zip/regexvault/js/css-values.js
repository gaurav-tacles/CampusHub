/**
 * css-values.js — rendering and lookup for the CSS Values reference.
 */
window.RegexVaultCss = (function () {
  "use strict";

  const { escapeHtml } = window.RegexVaultApp;
  const DATA = window.CSS_VALUES || [];

  function getAll() {
    return DATA;
  }

  function getById(id) {
    return DATA.find((entry) => entry.id === id) || null;
  }

  function getCategories() {
    const set = new Set(DATA.map((entry) => entry.category));
    return Array.from(set).sort();
  }

  function searchIndex() {
    return DATA.map((entry) => ({
      type: "css",
      id: entry.id,
      title: `${entry.name} — ${entry.label}`,
      category: entry.category,
      href: `css-value-detail.html?id=${encodeURIComponent(entry.id)}`,
      haystack: [entry.name, entry.label, entry.category, entry.definition].join(" ").toLowerCase()
    }));
  }

  function cardTemplate(entry) {
    const fav = window.RegexVaultFavorites;
    const isFav = fav ? fav.isFavorite("css", entry.id) : false;
    return `
      <a class="pattern-card" href="css-value-detail.html?id=${encodeURIComponent(entry.id)}" data-id="${entry.id}">
        <div class="pattern-card-top">
          <h3>${escapeHtml(entry.name)}</h3>
          <button type="button" class="fav-toggle" data-fav-toggle data-fav-type="css" data-fav-id="${entry.id}"
            data-fav-title="${escapeHtml(entry.name)}" aria-pressed="${isFav}"
            aria-label="${isFav ? "Remove from favorites: " : "Add to favorites: "}${escapeHtml(entry.name)}">${isFav ? "★" : "☆"}</button>
        </div>
        <span class="category-tag">${escapeHtml(entry.category)}</span>
        <p>${escapeHtml(entry.definition)}</p>
        <code class="mono-preview">${escapeHtml(entry.syntax)}</code>
      </a>`;
  }

  function renderList(mountSelector, entries) {
    const mount = document.querySelector(mountSelector);
    if (!mount) return;
    mount.innerHTML = entries.length ? entries.map(cardTemplate).join("") : "";
    if (window.RegexVaultFavorites) {
      window.RegexVaultFavorites.initToggleButtons(mount);
    }
  }

  function sortEntries(entries, mode) {
    const copy = entries.slice();
    if (mode === "az") {
      copy.sort((a, b) => a.name.localeCompare(b.name));
    } else if (mode === "recent") {
      copy.reverse();
    }
    // "popular" for CSS values falls back to the curated dataset order
    // (most commonly used units are listed first within each category).
    return copy;
  }

  function relatedEntries(entry) {
    return (entry.related || []).map(getById).filter(Boolean);
  }

  return {
    getAll,
    getById,
    getCategories,
    searchIndex,
    renderList,
    sortEntries,
    relatedEntries,
    cardTemplate
  };
})();

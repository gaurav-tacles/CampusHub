/**
 * RegexVault — Regex pattern dataset.
 *
 * Each entry describes ONE real-world regular expression. Multi-language
 * code samples and the token breakdown are generated at render time by
 * js/regex.js from `pattern` + `flags`, so this file only stores the
 * pattern itself plus human-authored copy (title, description, examples).
 *
 * flags is intentionally limited to "" or "i" — those are the two states
 * that translate unambiguously across every supported language. (Global,
 * multiline and dotall flags mean different things in different regex
 * engines, so mixing them into a single cross-language sample would risk
 * producing inaccurate code — see js/regex.js buildLanguageExamples.)
 */
window.REGEX_PATTERNS = [
  {
    id: "full-name",
    title: "Full Name",
    category: "Personal Information",
    description: "Matches a full name made of two or more word parts, allowing hyphens and apostrophes for names like \"O'Brien\" or \"Mary-Jane\".",
    pattern: "^[A-Za-z]+(?:[\\s'-][A-Za-z]+)+$",
    flags: "",
    keywords: ["name", "full name", "person", "surname"],
    examples: {
      valid: ["Gaurav Patel", "Mary-Jane O'Brien", "Anne Marie Curie"],
      invalid: ["Cher", "John123", "John  "]
    },
    note: "Single-word names (mononyms) won't match by design — loosen the pattern to `^[A-Za-z'-]+$` if those should be allowed."
  },
  {
    id: "first-name",
    title: "First Name",
    category: "Personal Information",
    description: "Matches a single given name of 2–30 letters, allowing internal hyphens and apostrophes.",
    pattern: "^[A-Za-z][A-Za-z'-]{1,29}$",
    flags: "",
    keywords: ["name", "first name", "given name"],
    examples: {
      valid: ["Gaurav", "Mary-Jane", "D'Angelo"],
      invalid: ["G", "123", "Gau_rav"]
    }
  },
  {
    id: "username",
    title: "Username",
    category: "Authentication",
    description: "Matches a username of 3–16 characters containing only letters, digits and underscores.",
    pattern: "^[a-zA-Z0-9_]{3,16}$",
    flags: "",
    keywords: ["username", "handle", "login", "account"],
    examples: {
      valid: ["dev_user1", "Gaurav99", "abc"],
      invalid: ["ab", "invalid username", "way_too_long_username_here"]
    }
  },
  {
    id: "initials",
    title: "Initials",
    category: "Personal Information",
    description: "Matches one to four capital-letter initials, each followed by a period (e.g. \"J.R.R.\").",
    pattern: "^([A-Z]\\.){1,4}$",
    flags: "",
    keywords: ["initials", "abbreviation", "name"],
    examples: {
      valid: ["J.R.R.", "A.", "M.J."],
      invalid: ["JRR", "j.r.", "A..B."]
    }
  },
  {
    id: "email-basic",
    title: "Email Validation",
    category: "Contact",
    description: "A lightweight check for the general shape of an email address: some text, an @, more text, a dot, more text.",
    pattern: "^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$",
    flags: "",
    keywords: ["email", "e-mail", "contact", "validation"],
    examples: {
      valid: ["user@example.com", "first.last@mail.co"],
      invalid: ["user@example", "user example.com", "@example.com"]
    },
    note: "This is intentionally simple. Real email addresses can be far more complex than the RFC 5322 spec allows for in a single readable pattern — see \"Strict Email Validation\" for a closer approximation, and consider sending a confirmation email as the real source of truth."
  },
  {
    id: "email-strict",
    title: "Strict Email Validation",
    category: "Contact",
    description: "A closer approximation of RFC 5322 email syntax, validating the local part, domain labels and TLD structure.",
    pattern: "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$",
    flags: "",
    keywords: ["email", "rfc 5322", "strict", "validation"],
    examples: {
      valid: ["first.last+tag@sub.example.com", "user_name@example.co.in"],
      invalid: ["@example.com", "user@.com", "user@example..com"]
    },
    note: "Still not fully RFC 5322 compliant — no regex practically is. Quoted local parts and IP-literal domains are deliberately out of scope."
  },
  {
    id: "phone-us",
    title: "US Phone Number",
    category: "Contact",
    description: "Matches a 10-digit US phone number with optional parentheses, dots, dashes or spaces as separators.",
    pattern: "^\\(?\\d{3}\\)?[\\s.-]?\\d{3}[\\s.-]?\\d{4}$",
    flags: "",
    keywords: ["phone", "telephone", "us", "contact"],
    examples: {
      valid: ["(555) 123-4567", "555-123-4567", "5551234567"],
      invalid: ["12345", "555-123-456", "+1-555-123-4567"]
    }
  },
  {
    id: "phone-intl",
    title: "International Phone Number",
    category: "Contact",
    description: "Matches an E.164 international phone number: a leading + followed by 2–15 digits, the first of which is non-zero.",
    pattern: "^\\+[1-9]\\d{1,14}$",
    flags: "",
    keywords: ["phone", "international", "e.164", "contact"],
    examples: {
      valid: ["+14155552671", "+919812345678"],
      invalid: ["14155552671", "+0123456789", "+1 415 555 2671"]
    }
  },
  {
    id: "postal-code-us",
    title: "US ZIP Code",
    category: "Location",
    description: "Matches a 5-digit US ZIP code with an optional 4-digit ZIP+4 extension.",
    pattern: "^\\d{5}(-\\d{4})?$",
    flags: "",
    keywords: ["zip", "postal code", "pin code", "location"],
    examples: {
      valid: ["94103", "94103-1234"],
      invalid: ["9410", "ABCDE", "94103-12"]
    }
  },
  {
    id: "password-strong",
    title: "Strong Password",
    category: "Authentication",
    description: "Requires at least 8 characters with a lowercase letter, an uppercase letter, a digit and a symbol, using lookaheads.",
    pattern: "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[^A-Za-z\\d]).{8,}$",
    flags: "",
    keywords: ["password", "strong password", "security", "authentication"],
    examples: {
      valid: ["Str0ng!Pass", "C0rrect#Horse"],
      invalid: ["weakpass", "12345678", "NoSymbolsHere1"]
    },
    note: "Length and character variety don't guarantee a password is actually strong — pair this with a breach-list check (e.g. Have I Been Pwned) for real protection."
  },
  {
    id: "password-basic",
    title: "Basic Password",
    category: "Authentication",
    description: "Requires at least 6 characters containing at least one letter and one digit.",
    pattern: "^(?=.*[A-Za-z])(?=.*\\d).{6,}$",
    flags: "",
    keywords: ["password", "basic", "authentication"],
    examples: {
      valid: ["abc123", "password1"],
      invalid: ["abcdef", "12345", "abc12"]
    }
  },
  {
    id: "otp-6",
    title: "6-Digit OTP",
    category: "Authentication",
    description: "Matches a one-time passcode made of exactly six digits.",
    pattern: "^\\d{6}$",
    flags: "",
    keywords: ["otp", "one-time password", "code", "2fa"],
    examples: {
      valid: ["482913", "000000"],
      invalid: ["12345", "12a456", "1234567"]
    }
  },
  {
    id: "pin-4",
    title: "4-Digit PIN",
    category: "Authentication",
    description: "Matches a numeric PIN of exactly four digits.",
    pattern: "^\\d{4}$",
    flags: "",
    keywords: ["pin", "security code", "numeric"],
    examples: {
      valid: ["4821", "0000"],
      invalid: ["482", "48a1", "48212"]
    }
  },
  {
    id: "integer",
    title: "Integer",
    category: "Numbers",
    description: "Matches a whole number, positive or negative, with no decimal point.",
    pattern: "^-?\\d+$",
    flags: "",
    keywords: ["integer", "whole number", "number"],
    examples: {
      valid: ["42", "-17", "0"],
      invalid: ["4.2", "abc", "1,000"]
    }
  },
  {
    id: "positive-integer",
    title: "Positive Integer",
    category: "Numbers",
    description: "Matches a whole number greater than zero, with no leading zeros.",
    pattern: "^[1-9]\\d*$",
    flags: "",
    keywords: ["integer", "positive", "number"],
    examples: {
      valid: ["1", "482", "9001"],
      invalid: ["0", "-5", "01"]
    }
  },
  {
    id: "negative-integer",
    title: "Negative Integer",
    category: "Numbers",
    description: "Matches a whole number less than zero, with no leading zeros after the minus sign.",
    pattern: "^-[1-9]\\d*$",
    flags: "",
    keywords: ["integer", "negative", "number"],
    examples: {
      valid: ["-1", "-482"],
      invalid: ["0", "5", "-01"]
    }
  },
  {
    id: "decimal",
    title: "Decimal Number",
    category: "Numbers",
    description: "Matches an integer or decimal number, positive or negative.",
    pattern: "^-?\\d+(\\.\\d+)?$",
    flags: "",
    keywords: ["decimal", "float", "number"],
    examples: {
      valid: ["3.14", "-2.5", "10"],
      invalid: ["3.", ".5", "3.14.15"]
    }
  },
  {
    id: "positive-decimal",
    title: "Positive Decimal",
    category: "Numbers",
    description: "Matches an integer or decimal number that is zero or greater.",
    pattern: "^\\d+(\\.\\d+)?$",
    flags: "",
    keywords: ["decimal", "positive", "float"],
    examples: {
      valid: ["3.14", "10", "0.5"],
      invalid: ["-3.14", "3."]
    }
  },
  {
    id: "percentage",
    title: "Percentage",
    category: "Numbers",
    description: "Matches a percentage value from 0% to 100%, with optional decimal places.",
    pattern: "^(100(\\.0+)?|\\d{1,2}(\\.\\d+)?)%$",
    flags: "",
    keywords: ["percentage", "percent", "number"],
    examples: {
      valid: ["45%", "100%", "0.5%"],
      invalid: ["101%", "45", "100.5%"]
    }
  },
  {
    id: "currency-usd",
    title: "Currency (USD)",
    category: "Numbers",
    description: "Matches a US dollar amount with a leading $, optional thousands separators and optional cents.",
    pattern: "^\\$\\d{1,3}(,\\d{3})*(\\.\\d{2})?$",
    flags: "",
    keywords: ["currency", "money", "usd", "price"],
    examples: {
      valid: ["$1,200.50", "$5", "$45,000"],
      invalid: ["1200.50", "$1,2345", "$5.5"]
    }
  },
  {
    id: "date-mdy",
    title: "Date (MM/DD/YYYY)",
    category: "Date & Time",
    description: "Matches a calendar date in US MM/DD/YYYY order, validating month and day ranges.",
    pattern: "^(0[1-9]|1[0-2])/(0[1-9]|[12]\\d|3[01])/\\d{4}$",
    flags: "",
    keywords: ["date", "mm/dd/yyyy", "us date"],
    examples: {
      valid: ["01/31/2024", "12/01/1999"],
      invalid: ["13/01/2024", "1/1/2024", "01/32/2024"]
    },
    note: "Range-checks the month and day (day up to 31), but not month-specific day counts (e.g. it accepts 02/30) — validate with a real date library for that."
  },
  {
    id: "date-iso",
    title: "ISO Date (YYYY-MM-DD)",
    category: "Date & Time",
    description: "Matches a calendar date in ISO 8601 order, validating month and day ranges.",
    pattern: "^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01])$",
    flags: "",
    keywords: ["date", "iso 8601", "yyyy-mm-dd"],
    examples: {
      valid: ["2024-01-31", "1999-12-01"],
      invalid: ["2024-13-01", "24-01-01", "2024-1-1"]
    }
  },
  {
    id: "time-24h",
    title: "Time (24-hour)",
    category: "Date & Time",
    description: "Matches a time in 24-hour HH:MM format, from 00:00 to 23:59.",
    pattern: "^([01]\\d|2[0-3]):[0-5]\\d$",
    flags: "",
    keywords: ["time", "24-hour", "clock"],
    examples: {
      valid: ["23:59", "08:05", "00:00"],
      invalid: ["24:00", "8:5", "23:60"]
    }
  },
  {
    id: "time-12h",
    title: "Time (12-hour)",
    category: "Date & Time",
    description: "Matches a time in 12-hour H:MM format with an AM/PM marker.",
    pattern: "^(0?[1-9]|1[0-2]):[0-5]\\d\\s?(AM|PM|am|pm)$",
    flags: "",
    keywords: ["time", "12-hour", "am pm", "clock"],
    examples: {
      valid: ["8:05 AM", "12:30pm", "11:59 PM"],
      invalid: ["13:00 AM", "08:60 AM", "8:05"]
    }
  },
  {
    id: "datetime-iso",
    title: "ISO DateTime",
    category: "Date & Time",
    description: "Matches a full ISO 8601 date and time, with an optional fractional second and timezone offset.",
    pattern: "^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01])T([01]\\d|2[0-3]):[0-5]\\d:[0-5]\\d(\\.\\d+)?(Z|[+-]\\d{2}:\\d{2})?$",
    flags: "",
    keywords: ["datetime", "iso 8601", "timestamp"],
    examples: {
      valid: ["2024-01-31T23:59:00Z", "2024-01-31T08:05:00+05:30"],
      invalid: ["2024-01-31 23:59:00", "2024-01-31T25:00:00Z"]
    }
  },
  {
    id: "year",
    title: "Year",
    category: "Date & Time",
    description: "Matches a four-digit year between 1900 and 2099.",
    pattern: "^(19|20)\\d{2}$",
    flags: "",
    keywords: ["year", "date"],
    examples: {
      valid: ["1999", "2026"],
      invalid: ["99", "3000", "18999"]
    }
  },
  {
    id: "url-http",
    title: "HTTP/HTTPS URL",
    category: "Web",
    description: "Matches an http:// or https:// URL with a domain and optional path.",
    pattern: "^https?://[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]+)+([/\\w .-]*)*/?$",
    flags: "",
    keywords: ["url", "link", "http", "https"],
    examples: {
      valid: ["https://example.com/path", "http://sub.example.co/a/b"],
      invalid: ["ftp://example.com", "example.com", "https:/example.com"]
    },
    note: "Covers common URLs but not query strings or fragments — extend the pattern if you need to validate `?query` or `#fragment` parts too."
  },
  {
    id: "domain",
    title: "Domain Name",
    category: "Web",
    description: "Matches a domain name made of dot-separated labels, disallowing labels that start or end with a hyphen.",
    pattern: "^(?!-)[A-Za-z0-9-]{1,63}(?<!-)(\\.[A-Za-z]{2,})+$",
    flags: "",
    keywords: ["domain", "hostname", "web"],
    examples: {
      valid: ["example.com", "my-site.co.uk"],
      invalid: ["-example.com", "example", "example-.com"]
    },
    note: "Uses a lookbehind, so it needs an engine with lookbehind support (all languages covered here qualify)."
  },
  {
    id: "subdomain",
    title: "Subdomain",
    category: "Web",
    description: "Matches a hostname with at least one subdomain label before the root domain.",
    pattern: "^[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\\.[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$",
    flags: "",
    keywords: ["subdomain", "hostname", "web"],
    examples: {
      valid: ["api.example.com", "shop.staging.example.co"],
      invalid: ["example.com", ".example.com"]
    }
  },
  {
    id: "ipv4",
    title: "IPv4 Address",
    category: "Web",
    description: "Matches an IPv4 address, validating that each octet is between 0 and 255.",
    pattern: "^((25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]?\\d)\\.){3}(25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]?\\d)$",
    flags: "",
    keywords: ["ip", "ipv4", "address", "network"],
    examples: {
      valid: ["192.168.1.1", "8.8.8.8"],
      invalid: ["999.1.1.1", "192.168.1", "192.168.1.1.1"]
    }
  },
  {
    id: "ipv6",
    title: "IPv6 Address",
    category: "Web",
    description: "Matches a full, uncompressed IPv6 address made of eight colon-separated hextets.",
    pattern: "^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$",
    flags: "",
    keywords: ["ip", "ipv6", "address", "network"],
    examples: {
      valid: ["2001:0db8:85a3:0000:0000:8a2e:0370:7334"],
      invalid: ["2001:0db8::1", "2001:0db8:85a3"]
    },
    note: "Doesn't handle the \"::\" zero-compression shorthand — that needs a more elaborate pattern or, better, your language's built-in IP parser."
  },
  {
    id: "variable-name",
    title: "Variable Name (Identifier)",
    category: "Programming",
    description: "Matches a typical programming identifier: starts with a letter, underscore or dollar sign, followed by letters, digits, underscores or dollar signs.",
    pattern: "^[a-zA-Z_$][a-zA-Z0-9_$]*$",
    flags: "",
    keywords: ["variable", "identifier", "programming"],
    examples: {
      valid: ["_value", "$element", "userName1"],
      invalid: ["1user", "user-name", "user name"]
    }
  },
  {
    id: "hex-color",
    title: "Hex Color Code",
    category: "Programming",
    description: "Matches a CSS hex color in 3- or 6-digit shorthand, with a leading #.",
    pattern: "^#(?:[0-9a-fA-F]{3}){1,2}$",
    flags: "",
    keywords: ["hex color", "css", "color code"],
    examples: {
      valid: ["#fff", "#1A2b3C"],
      invalid: ["#12345", "fff", "#gghhii"]
    }
  },
  {
    id: "binary-number",
    title: "Binary Number",
    category: "Programming",
    description: "Matches a string of only 0s and 1s.",
    pattern: "^[01]+$",
    flags: "",
    keywords: ["binary", "base 2", "number"],
    examples: {
      valid: ["1010", "0", "111000"],
      invalid: ["102", "abc"]
    }
  },
  {
    id: "octal-number",
    title: "Octal Number",
    category: "Programming",
    description: "Matches a legacy-style octal literal: a leading 0 followed by digits 0–7.",
    pattern: "^0[0-7]+$",
    flags: "",
    keywords: ["octal", "base 8", "number"],
    examples: {
      valid: ["017", "0755"],
      invalid: ["089", "17"]
    }
  },
  {
    id: "hexadecimal-number",
    title: "Hexadecimal Number",
    category: "Programming",
    description: "Matches a 0x-prefixed hexadecimal literal.",
    pattern: "^0[xX][0-9a-fA-F]+$",
    flags: "",
    keywords: ["hexadecimal", "hex", "base 16", "number"],
    examples: {
      valid: ["0x1A3F", "0xff"],
      invalid: ["1A3F", "0xGG"]
    }
  },
  {
    id: "single-line-comment",
    title: "Single-Line Comment",
    category: "Programming",
    description: "Matches a C-style single-line comment starting with //.",
    pattern: "^//.*$",
    flags: "",
    keywords: ["comment", "code", "programming"],
    examples: {
      valid: ["// this is a comment", "//TODO: fix this"],
      invalid: ["/* not this */", "not a comment"]
    }
  },
  {
    id: "file-extension",
    title: "File Extension",
    category: "Files",
    description: "Matches the file extension at the end of a filename.",
    pattern: "\\.([a-zA-Z0-9]+)$",
    flags: "",
    keywords: ["file extension", "filename", "files"],
    examples: {
      valid: ["report.pdf", "archive.tar.gz"],
      invalid: ["report", "report."]
    }
  },
  {
    id: "hashtag",
    title: "Hashtag",
    category: "Social",
    description: "Matches a social-media hashtag: a # followed by letters, digits or underscores.",
    pattern: "^#[A-Za-z0-9_]+$",
    flags: "",
    keywords: ["hashtag", "social media", "tag"],
    examples: {
      valid: ["#DevLife", "#100DaysOfCode"],
      invalid: ["# space", "hashtag", "#"]
    }
  },
  {
    id: "mention",
    title: "Mention (@username)",
    category: "Social",
    description: "Matches an @-mention of 1–15 letters, digits or underscores, similar to Twitter/X handles.",
    pattern: "^@[A-Za-z0-9_]{1,15}$",
    flags: "",
    keywords: ["mention", "handle", "social media"],
    examples: {
      valid: ["@gaurav_dev", "@user1"],
      invalid: ["gaurav", "@", "@way_too_long_handle"]
    }
  },
  {
    id: "coordinates-latlng",
    title: "Latitude/Longitude Coordinate",
    category: "Location",
    description: "Matches a comma-separated latitude,longitude pair with valid ranges (-90 to 90, -180 to 180).",
    pattern: "^-?([1-8]?\\d(\\.\\d+)?|90(\\.0+)?),\\s*-?(180(\\.0+)?|((1[0-7]\\d)|([1-9]?\\d))(\\.\\d+)?)$",
    flags: "",
    keywords: ["coordinates", "latitude", "longitude", "gps"],
    examples: {
      valid: ["40.7128,-74.0060", "-33.8688, 151.2093"],
      invalid: ["200,100", "40.7128"]
    }
  },
  {
    id: "uuid-v4",
    title: "UUID v4",
    category: "IDs",
    description: "Matches a version-4 UUID, checking the version and variant nibbles.",
    pattern: "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-4[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$",
    flags: "",
    keywords: ["uuid", "guid", "identifier"],
    examples: {
      valid: ["550e8400-e29b-41d4-a716-446655440000"],
      invalid: ["550e8400-e29b-11d4-a716-446655440000", "not-a-uuid"]
    }
  },
  {
    id: "numeric-id",
    title: "Numeric ID",
    category: "IDs",
    description: "Matches a numeric identifier of 4 to 10 digits.",
    pattern: "^\\d{4,10}$",
    flags: "",
    keywords: ["id", "numeric id", "identifier"],
    examples: {
      valid: ["482913", "1000"],
      invalid: ["12", "12a34"]
    }
  },
  {
    id: "alphanumeric-id",
    title: "Alphanumeric ID",
    category: "IDs",
    description: "Matches an identifier of 6 to 12 letters and digits.",
    pattern: "^[A-Za-z0-9]{6,12}$",
    flags: "",
    keywords: ["id", "alphanumeric", "identifier"],
    examples: {
      valid: ["A1b2C3d4", "order99"],
      invalid: ["abc", "abc-123"]
    }
  },
  {
    id: "image-extension",
    title: "Image File Name",
    category: "Files",
    description: "Matches a filename ending in a common image extension, case-insensitively.",
    pattern: "\\.(jpe?g|png|gif|webp|svg|bmp)$",
    flags: "i",
    keywords: ["image", "file extension", "files"],
    examples: {
      valid: ["photo.PNG", "icon.svg", "banner.jpeg"],
      invalid: ["photo.txt", "document.pdf"]
    }
  },
  {
    id: "alphanumeric",
    title: "Alphanumeric Only",
    category: "Text",
    description: "Matches a string made only of letters and digits.",
    pattern: "^[a-zA-Z0-9]+$",
    flags: "",
    keywords: ["alphanumeric", "letters and numbers", "text"],
    examples: {
      valid: ["Abc123", "userID9"],
      invalid: ["abc 123", "abc-123"]
    }
  },
  {
    id: "letters-only",
    title: "Letters Only",
    category: "Text",
    description: "Matches a string made only of upper- or lower-case letters.",
    pattern: "^[a-zA-Z]+$",
    flags: "",
    keywords: ["letters only", "alphabetic", "text"],
    examples: {
      valid: ["Hello", "abcXYZ"],
      invalid: ["Hello1", "Hello!"]
    }
  },
  {
    id: "letters-and-spaces",
    title: "Letters and Spaces",
    category: "Text",
    description: "Matches a string made only of letters and whitespace.",
    pattern: "^[a-zA-Z\\s]+$",
    flags: "",
    keywords: ["letters", "spaces", "text"],
    examples: {
      valid: ["Hello World", "a b c"],
      invalid: ["Hello1", "Hello!"]
    }
  },
  {
    id: "whitespace",
    title: "Whitespace",
    category: "Text",
    description: "Matches a string made entirely of whitespace characters.",
    pattern: "^\\s+$",
    flags: "",
    keywords: ["whitespace", "blank", "text"],
    examples: {
      valid: ["   ", "\t\n"],
      invalid: ["a b", ""]
    }
  },
  {
    id: "non-whitespace",
    title: "Non-Whitespace",
    category: "Text",
    description: "Matches a string containing no whitespace characters at all.",
    pattern: "^\\S+$",
    flags: "",
    keywords: ["non-whitespace", "no spaces", "text"],
    examples: {
      valid: ["abc123!", "no-spaces-here"],
      invalid: ["a b", " "]
    }
  },
  {
    id: "slug",
    title: "URL Slug",
    category: "Web",
    description: "Matches a lowercase, hyphen-separated URL slug commonly used for blog posts and product pages.",
    pattern: "^[a-z0-9]+(?:-[a-z0-9]+)*$",
    flags: "",
    keywords: ["slug", "url slug", "permalink", "web"],
    examples: {
      valid: ["my-blog-post-1", "regexvault"],
      invalid: ["My Blog Post", "-slug", "double--dash"]
    }
  },
  {
    id: "html-tag",
    title: "HTML Tag (Basic)",
    category: "Programming",
    description: "Matches a simple, non-nested HTML element with an opening and matching closing tag.",
    pattern: "^<([a-z][a-z0-9]*)\\b[^>]*>(.*?)</\\1>$",
    flags: "i",
    keywords: ["html", "tag", "markup"],
    examples: {
      valid: ["<p>Hello</p>", "<div class=\"card\">Text</div>"],
      invalid: ["<p>Hello</div>", "<br>"]
    },
    note: "Regex is not a reliable way to parse arbitrary or nested HTML — use a real HTML/DOM parser for anything beyond a quick single-tag check."
  }
];

/**
 * RegexVault — CSS values & units dataset.
 * Every unit CSS actually defines gets its own entry; nothing invented.
 */
window.CSS_VALUES = [
  // ---------- Absolute length units ----------
  {
    id: "px",
    name: "px",
    label: "Pixel",
    category: "Absolute Units",
    definition: "A pixel. In CSS, one px is defined as 1/96th of an inch, and is treated as a fixed reference length rather than a true hardware pixel on modern (high-DPI) screens.",
    syntax: "<length-value>px",
    example: ".box {\n  width: 240px;\n  border: 1px solid #ccc;\n}",
    result: "The box is exactly 240 CSS pixels wide, regardless of the root or parent font size.",
    related: ["em", "rem", "pt"]
  },
  {
    id: "cm",
    name: "cm",
    label: "Centimeter",
    category: "Absolute Units",
    definition: "A physical centimeter. 1cm equals 37.8px.",
    syntax: "<length-value>cm",
    example: "@page {\n  margin: 2cm;\n}",
    result: "Each page margin is set to a physical 2 centimeters — useful mainly for print stylesheets.",
    related: ["mm", "in", "pt"]
  },
  {
    id: "mm",
    name: "mm",
    label: "Millimeter",
    category: "Absolute Units",
    definition: "A physical millimeter. 1mm equals 1/10th of a centimeter, or 3.78px.",
    syntax: "<length-value>mm",
    example: "@page {\n  margin: 15mm;\n}",
    result: "The printed page gets a 15 millimeter margin on every side.",
    related: ["cm", "in", "pt"]
  },
  {
    id: "in",
    name: "in",
    label: "Inch",
    category: "Absolute Units",
    definition: "A physical inch. 1in equals 2.54cm, or 96px.",
    syntax: "<length-value>in",
    example: "@page {\n  size: 8.5in 11in;\n}",
    result: "Defines a US Letter page size for print output.",
    related: ["cm", "pt", "px"]
  },
  {
    id: "pt",
    name: "pt",
    label: "Point",
    category: "Absolute Units",
    definition: "A typographic point, commonly used in print and word-processing typography. 1pt equals 1/72nd of an inch, or about 1.33px.",
    syntax: "<length-value>pt",
    example: "body {\n  font-size: 12pt;\n}",
    result: "Sets body text to 12 points — roughly 16px on screen.",
    related: ["pc", "px", "in"]
  },
  {
    id: "pc",
    name: "pc",
    label: "Pica",
    category: "Absolute Units",
    definition: "A typographic pica. 1pc equals 12pt, or 1/6th of an inch.",
    syntax: "<length-value>pc",
    example: ".column {\n  width: 20pc;\n}",
    result: "The column is 20 picas wide, equivalent to 240 points.",
    related: ["pt", "in"]
  },

  // ---------- Relative length units ----------
  {
    id: "em",
    name: "em",
    label: "Em",
    category: "Relative Units",
    definition: "A relative length unit based on the font size of the element it is used on (or the parent's font size, for font-size itself). 1em equals that element's current font size.",
    syntax: "<number>em",
    example: ".card {\n  font-size: 18px;\n  padding: 1.5em;\n}",
    result: "The card's padding is 1.5 × 18px = 27px, and stays proportional if font-size changes.",
    related: ["rem", "ch", "ex"],
    browserNote: "Because em compounds with nested font sizes, deeply nested elements can grow unpredictably — rem avoids that by always referencing the root."
  },
  {
    id: "rem",
    name: "rem",
    label: "Root Em",
    category: "Relative Units",
    definition: "A relative CSS length unit based on the root element's (<html>) font size, regardless of nesting.",
    syntax: "<number>rem",
    example: "html {\n  font-size: 16px;\n}\n\n.title {\n  font-size: 2rem;\n}",
    result: "2rem means 2 × 16px = 32px, no matter how deeply .title is nested.",
    related: ["em", "px"]
  },
  {
    id: "ex",
    name: "ex",
    label: "X-Height",
    category: "Relative Units",
    definition: "A relative length unit based on the x-height of the element's font — roughly the height of a lowercase \"x\" in the current typeface.",
    syntax: "<number>ex",
    example: ".highlight {\n  padding-bottom: 0.2ex;\n}",
    result: "The padding scales with the visual height of lowercase letters in the current font.",
    related: ["em", "ch"]
  },
  {
    id: "ch",
    name: "ch",
    label: "Character Width",
    category: "Relative Units",
    definition: "A relative length unit based on the advance width of the \"0\" (zero) character in the element's font.",
    syntax: "<number>ch",
    example: "input[type=\"text\"] {\n  width: 20ch;\n}",
    result: "The text input is roughly as wide as 20 zero characters — handy for sizing inputs to a known number of digits.",
    related: ["em", "rem"]
  },

  // ---------- Viewport units ----------
  {
    id: "vw",
    name: "vw",
    label: "Viewport Width",
    category: "Viewport Units",
    definition: "1vw equals 1% of the viewport's width.",
    syntax: "<number>vw",
    example: ".hero {\n  font-size: 5vw;\n}",
    result: "The hero text scales directly with the browser window's width.",
    related: ["vh", "vmin", "vmax"]
  },
  {
    id: "vh",
    name: "vh",
    label: "Viewport Height",
    category: "Viewport Units",
    definition: "1vh equals 1% of the viewport's height.",
    syntax: "<number>vh",
    example: ".hero {\n  min-height: 100vh;\n}",
    result: "The hero section is always at least as tall as the visible browser window.",
    related: ["vw", "svh", "dvh"],
    browserNote: "On mobile browsers, 100vh can include space behind a collapsing address bar. Use svh or dvh when you need the visible area to match exactly."
  },
  {
    id: "vmin",
    name: "vmin",
    label: "Viewport Minimum",
    category: "Viewport Units",
    definition: "1vmin equals 1% of whichever viewport dimension (width or height) is smaller.",
    syntax: "<number>vmin",
    example: ".square {\n  width: 50vmin;\n  height: 50vmin;\n}",
    result: "The square is always half the size of the shorter viewport dimension, so it fits on both portrait and landscape screens.",
    related: ["vmax", "vw", "vh"]
  },
  {
    id: "vmax",
    name: "vmax",
    label: "Viewport Maximum",
    category: "Viewport Units",
    definition: "1vmax equals 1% of whichever viewport dimension (width or height) is larger.",
    syntax: "<number>vmax",
    example: ".banner {\n  font-size: 4vmax;\n}",
    result: "The banner text scales with whichever dimension is currently larger — the width in landscape, the height in portrait.",
    related: ["vmin", "vw", "vh"]
  },
  {
    id: "svw",
    name: "svw",
    label: "Small Viewport Width",
    category: "Viewport Units",
    definition: "1svw equals 1% of the small viewport width — the viewport size when dynamic mobile browser UI (like an address bar) is fully expanded.",
    syntax: "<number>svw",
    example: ".panel {\n  width: 100svw;\n}",
    result: "The panel matches the width of the smallest possible viewport state, so it never overflows even with browser UI expanded.",
    related: ["vw", "lvw", "dvw"]
  },
  {
    id: "svh",
    name: "svh",
    label: "Small Viewport Height",
    category: "Viewport Units",
    definition: "1svh equals 1% of the small viewport height — the viewport size when dynamic mobile browser UI is fully expanded (taking up the most space).",
    syntax: "<number>svh",
    example: ".sheet {\n  min-height: 100svh;\n}",
    result: "The sheet fills the viewport height even when the browser's address bar is visible, avoiding layout jumps.",
    related: ["vh", "lvh", "dvh"],
    browserNote: "Supported in all current major browsers; older browsers fall back to treating it as an unrecognized unit, so pair it with a vh fallback."
  },
  {
    id: "lvw",
    name: "lvw",
    label: "Large Viewport Width",
    category: "Viewport Units",
    definition: "1lvw equals 1% of the large viewport width — the viewport size when dynamic mobile browser UI is fully collapsed (taking up the least space).",
    syntax: "<number>lvw",
    example: ".backdrop {\n  width: 100lvw;\n}",
    result: "The backdrop matches the widest possible viewport state, filling the screen once the browser UI collapses.",
    related: ["vw", "svw", "dvw"]
  },
  {
    id: "lvh",
    name: "lvh",
    label: "Large Viewport Height",
    category: "Viewport Units",
    definition: "1lvh equals 1% of the large viewport height — the viewport size when dynamic mobile browser UI is fully collapsed.",
    syntax: "<number>lvh",
    example: ".cover {\n  height: 100lvh;\n}",
    result: "The cover image is sized for the tallest possible viewport state.",
    related: ["vh", "svh", "dvh"]
  },
  {
    id: "dvw",
    name: "dvw",
    label: "Dynamic Viewport Width",
    category: "Viewport Units",
    definition: "1dvw equals 1% of the dynamic viewport width, which updates live as mobile browser UI expands or collapses.",
    syntax: "<number>dvw",
    example: ".stage {\n  width: 100dvw;\n}",
    result: "The stage always matches the current, real-time viewport width as the browser chrome changes.",
    related: ["vw", "svw", "lvw"]
  },
  {
    id: "dvh",
    name: "dvh",
    label: "Dynamic Viewport Height",
    category: "Viewport Units",
    definition: "1dvh equals 1% of the dynamic viewport height, which updates live as mobile browser UI expands or collapses.",
    syntax: "<number>dvh",
    example: ".fullscreen {\n  height: 100dvh;\n}",
    result: "The element's height continuously tracks the visible viewport, including as a mobile address bar shows or hides.",
    related: ["vh", "svh", "lvh"]
  },

  // ---------- Percentage ----------
  {
    id: "percent",
    name: "%",
    label: "Percentage",
    category: "Percentage",
    definition: "A percentage relative to another value — most often the corresponding dimension of the containing block, but the reference value depends on the property being set.",
    syntax: "<number>%",
    example: ".column {\n  width: 50%;\n}",
    result: "The column is half as wide as its parent container.",
    related: ["vw", "fr"]
  },

  // ---------- Container query units ----------
  {
    id: "cqw",
    name: "cqw",
    label: "Container Query Width",
    category: "Container Query Units",
    definition: "1cqw equals 1% of a query container's width.",
    syntax: "<number>cqw",
    example: ".card {\n  container-type: inline-size;\n}\n\n.card h2 {\n  font-size: 8cqw;\n}",
    result: "The heading scales with the width of its nearest query container, not the viewport.",
    related: ["cqi", "vw"],
    browserNote: "Requires the container to have container-type set — see MDN's Container Queries guide for setup."
  },
  {
    id: "cqh",
    name: "cqh",
    label: "Container Query Height",
    category: "Container Query Units",
    definition: "1cqh equals 1% of a query container's height.",
    syntax: "<number>cqh",
    example: ".panel {\n  padding-block: 4cqh;\n}",
    result: "Vertical padding scales with the height of the nearest query container.",
    related: ["cqb", "vh"]
  },
  {
    id: "cqi",
    name: "cqi",
    label: "Container Query Inline Size",
    category: "Container Query Units",
    definition: "1cqi equals 1% of a query container's inline-size (width, in most horizontal writing modes).",
    syntax: "<number>cqi",
    example: ".card__title {\n  font-size: 6cqi;\n}",
    result: "Font size scales with the container's inline dimension, respecting the current writing mode.",
    related: ["cqw", "cqb"]
  },
  {
    id: "cqb",
    name: "cqb",
    label: "Container Query Block Size",
    category: "Container Query Units",
    definition: "1cqb equals 1% of a query container's block-size (height, in most horizontal writing modes).",
    syntax: "<number>cqb",
    example: ".sidebar {\n  gap: 2cqb;\n}",
    result: "The gap scales with the container's block dimension.",
    related: ["cqh", "cqi"]
  },
  {
    id: "cqmin",
    name: "cqmin",
    label: "Container Query Minimum",
    category: "Container Query Units",
    definition: "1cqmin equals 1% of whichever container query dimension (cqi or cqb) is smaller.",
    syntax: "<number>cqmin",
    example: ".badge {\n  width: 20cqmin;\n  height: 20cqmin;\n}",
    result: "The badge stays proportional to the smaller of the container's two dimensions.",
    related: ["cqmax", "vmin"]
  },
  {
    id: "cqmax",
    name: "cqmax",
    label: "Container Query Maximum",
    category: "Container Query Units",
    definition: "1cqmax equals 1% of whichever container query dimension (cqi or cqb) is larger.",
    syntax: "<number>cqmax",
    example: ".hero-text {\n  font-size: 10cqmax;\n}",
    result: "Text size tracks the larger of the container's two dimensions.",
    related: ["cqmin", "vmax"]
  },

  // ---------- Grid ----------
  {
    id: "fr",
    name: "fr",
    label: "Fraction",
    category: "Grid",
    definition: "A fractional unit used only inside CSS Grid track sizing, representing a share of the leftover space in the grid container.",
    syntax: "<number>fr",
    example: ".grid {\n  display: grid;\n  grid-template-columns: 1fr 2fr;\n}",
    result: "The leftover space is split into three shares — the first column gets one share, the second gets two, so the second column is twice as wide.",
    related: ["percent"]
  },

  // ---------- Angle ----------
  {
    id: "deg",
    name: "deg",
    label: "Degree",
    category: "Angle Units",
    definition: "An angle measured in degrees, where a full circle is 360deg.",
    syntax: "<number>deg",
    example: ".icon {\n  transform: rotate(45deg);\n}",
    result: "The icon is rotated 45 degrees clockwise.",
    related: ["rad", "turn", "grad"]
  },
  {
    id: "grad",
    name: "grad",
    label: "Gradian",
    category: "Angle Units",
    definition: "An angle measured in gradians, where a full circle is 400grad.",
    syntax: "<number>grad",
    example: ".dial {\n  transform: rotate(100grad);\n}",
    result: "The dial rotates a quarter turn — 100 gradians is 90 degrees.",
    related: ["deg", "turn"]
  },
  {
    id: "rad",
    name: "rad",
    label: "Radian",
    category: "Angle Units",
    definition: "An angle measured in radians, where a full circle is 2π (about 6.2832) radians.",
    syntax: "<number>rad",
    example: ".needle {\n  transform: rotate(1.5708rad);\n}",
    result: "The needle rotates 90 degrees, since 1.5708 radians is π/2.",
    related: ["deg", "turn"]
  },
  {
    id: "turn",
    name: "turn",
    label: "Turn",
    category: "Angle Units",
    definition: "An angle measured in full turns, where 1turn equals 360deg.",
    syntax: "<number>turn",
    example: ".spinner {\n  animation: spin 2s linear infinite;\n}\n\n@keyframes spin {\n  to { transform: rotate(1turn); }\n}",
    result: "The spinner completes one full 360-degree rotation every 2 seconds.",
    related: ["deg", "rad"]
  },

  // ---------- Time ----------
  {
    id: "s",
    name: "s",
    label: "Second",
    category: "Time Units",
    definition: "A duration measured in seconds, used for transitions, animations and delays.",
    syntax: "<number>s",
    example: ".fade {\n  transition: opacity 0.3s ease;\n}",
    result: "The opacity change animates smoothly over 0.3 seconds.",
    related: ["ms"]
  },
  {
    id: "ms",
    name: "ms",
    label: "Millisecond",
    category: "Time Units",
    definition: "A duration measured in milliseconds. 1000ms equals 1s.",
    syntax: "<number>ms",
    example: ".tooltip {\n  transition-delay: 150ms;\n}",
    result: "The tooltip waits 150 milliseconds before its transition starts.",
    related: ["s"]
  },

  // ---------- Resolution ----------
  {
    id: "dpi",
    name: "dpi",
    label: "Dots Per Inch",
    category: "Resolution Units",
    definition: "A resolution measured in dots per inch, typically used inside media queries to target high-density screens.",
    syntax: "<number>dpi",
    example: "@media (min-resolution: 192dpi) {\n  .logo {\n    background-image: url(\"logo@2x.png\");\n  }\n}",
    result: "A higher-resolution logo image is served on screens with at least 192 dots per inch.",
    related: ["dpcm", "dppx"]
  },
  {
    id: "dpcm",
    name: "dpcm",
    label: "Dots Per Centimeter",
    category: "Resolution Units",
    definition: "A resolution measured in dots per centimeter. 1dpcm equals about 2.54dpi.",
    syntax: "<number>dpcm",
    example: "@media (min-resolution: 75dpcm) {\n  .banner {\n    background-image: url(\"banner-hd.png\");\n  }\n}",
    result: "The high-resolution banner image loads on screens denser than 75 dots per centimeter.",
    related: ["dpi", "dppx"]
  },
  {
    id: "dppx",
    name: "dppx",
    label: "Dots Per Pixel Unit",
    category: "Resolution Units",
    definition: "A resolution measured in dots per CSS pixel. 1dppx equals 96dpi, and matches the meaning of a device's devicePixelRatio.",
    syntax: "<number>dppx",
    example: "@media (min-resolution: 2dppx) {\n  .icon {\n    background-image: url(\"icon@2x.png\");\n  }\n}",
    result: "The @2x icon is used on screens with a device pixel ratio of 2 or higher, like most modern phone screens.",
    related: ["dpi", "dpcm"]
  }
];
